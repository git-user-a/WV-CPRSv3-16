This is the DUNIT test project for Orpheus.
This is only a starting point! Many more tests need to be added.

Its purpose it to prevent us from breaking existing code when we deploy a new version.

As bugs are found, it would be nice if someone would add a test to reproduce the bug.
That way bugs don't sneak back into future versions.

Note: The sub directory testfiles should be treated with care as some of the unit tests depend
on these files being present and in a fixed location.

Roman Kassebaum 



